using UnityEngine;

public class TrafficSpawner : MonoBehaviour
{
    public GameObject trafficPrefab;
    public Transform[] waypoints;
    [Range(0, 20)] public int trafficCount = 8;
    public float spawnOffset = 7f;
    public float speedMin = 8f;
    public float speedMax = 15f;

    void Start()
    {
        if (trafficPrefab == null || waypoints == null || waypoints.Length < 2) return;
        for (int i = 0; i < trafficCount; i++)
        {
            int index = Random.Range(0, waypoints.Length);
            Vector3 position = waypoints[index].position + Vector3.right * Random.Range(-spawnOffset, spawnOffset);
            GameObject car = Instantiate(trafficPrefab, position, waypoints[index].rotation);
            TrafficCarAI ai = car.GetComponent<TrafficCarAI>();
            if (ai == null) ai = car.AddComponent<TrafficCarAI>();
            ai.waypoints = waypoints;
            ai.speed = Random.Range(speedMin, speedMax);
        }
    }
}

using UnityEngine;
using UnityEngine.UI;

public class NeonAudioSettings : MonoBehaviour
{
    public AudioSource musicSource;
    public Slider volumeSlider;

    void Start()
    {
        float volume = PlayerPrefs.GetFloat("NEON_VOLUME", 0.65f);
        AudioListener.volume = volume;
        if (volumeSlider != null)
        {
            volumeSlider.SetValueWithoutNotify(volume);
            volumeSlider.onValueChanged.AddListener(SetVolume);
        }
        if (musicSource != null && !musicSource.isPlaying) musicSource.Play();
    }

    public void SetVolume(float value)
    {
        AudioListener.volume = value;
        PlayerPrefs.SetFloat("NEON_VOLUME", value);
    }

    public void SetQuality(int index)
    {
        QualitySettings.SetQualityLevel(Mathf.Clamp(index, 0, QualitySettings.names.Length - 1), true);
        PlayerPrefs.SetInt("NEON_QUALITY", index);
    }

    public void ToggleMusic(bool enabled)
    {
        if (musicSource == null) return;
        musicSource.mute = !enabled;
        PlayerPrefs.SetInt("NEON_MUSIC", enabled ? 1 : 0);
    }
}

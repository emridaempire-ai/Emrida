using UnityEngine;

// Add to emissive signs, strips and windows. Uses a material instance per object.
public class NeonPulse : MonoBehaviour
{
    public Color neonColor = new Color(0.05f, 0.8f, 1f);
    public float minimumEmission = 1.2f;
    public float maximumEmission = 3.2f;
    public float pulseSpeed = 1.4f;
    Renderer rend;
    Material materialInstance;

    void Awake()
    {
        rend = GetComponent<Renderer>();
        if (rend != null)
        {
            materialInstance = rend.material;
            materialInstance.EnableKeyword("_EMISSION");
        }
    }

    void Update()
    {
        if (materialInstance == null) return;
        float pulse = Mathf.Lerp(minimumEmission, maximumEmission,
            (Mathf.Sin(Time.time * pulseSpeed) + 1f) * 0.5f);
        materialInstance.SetColor("_EmissionColor", neonColor * pulse);
    }

    void OnDestroy()
    {
        if (materialInstance != null) Destroy(materialInstance);
    }
}

using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RaceManager : MonoBehaviour
{
    public Transform player;
    public Transform finishLine;
    public TMP_Text speedLabel;
    public TMP_Text statusLabel;
    public GameObject finishPanel;

    bool finished;
    Rigidbody playerBody;

    void Start()
    {
        if (player != null) playerBody = player.GetComponent<Rigidbody>();
        if (finishPanel != null) finishPanel.SetActive(false);
        if (statusLabel != null) statusLabel.text = "REACH THE CHECKPOINT";
    }

    void Update()
    {
        if (player == null) return;

        float speedKmh = playerBody != null ? playerBody.velocity.magnitude * 3.6f : 0f;
        if (speedLabel != null) speedLabel.text = Mathf.RoundToInt(speedKmh) + " KM/H";

        if (!finished && finishLine != null &&
            Vector3.Distance(player.position, finishLine.position) < 7f)
        {
            finished = true;
            if (statusLabel != null) statusLabel.text = "RACE COMPLETE";
            if (finishPanel != null) finishPanel.SetActive(true);
        }
    }

    public void RestartRace()
    {
        if (player == null) return;
        player.position = Vector3.up + Vector3.back * 8f;
        player.rotation = Quaternion.identity;
        if (playerBody != null)
        {
            playerBody.velocity = Vector3.zero;
            playerBody.angularVelocity = Vector3.zero;
        }
        finished = false;
        if (finishPanel != null) finishPanel.SetActive(false);
        if (statusLabel != null) statusLabel.text = "REACH THE CHECKPOINT";
    }
}

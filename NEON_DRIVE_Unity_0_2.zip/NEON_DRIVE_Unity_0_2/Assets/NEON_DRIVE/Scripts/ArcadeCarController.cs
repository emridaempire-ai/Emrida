using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class ArcadeCarController : MonoBehaviour
{
    [Header("Driving")]
    public float acceleration = 26f;
    public float reverseAcceleration = 12f;
    public float maxSpeed = 34f;
    public float steering = 95f;
    public float brakePower = 8f;
    public float lateralGrip = 5.5f;

    [Header("Visuals")]
    public Transform carVisual;
    public float visualLean = 10f;

    Rigidbody body;
    float throttle;
    float steer;
    bool braking;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.mass = 1200f;
        body.drag = 0.15f;
        body.angularDrag = 3f;
        body.centerOfMass = new Vector3(0f, -0.45f, 0f);
        body.interpolation = RigidbodyInterpolation.Interpolate;
    }

    public void SetInput(float gas, float turn, bool brake)
    {
        throttle = Mathf.Clamp(gas, -1f, 1f);
        steer = Mathf.Clamp(turn, -1f, 1f);
        braking = brake;
    }

    void FixedUpdate()
    {
        Vector3 localVelocity = transform.InverseTransformDirection(body.velocity);
        float forwardSpeed = localVelocity.z;

        if (throttle > 0f && body.velocity.magnitude < maxSpeed)
            body.AddForce(transform.forward * throttle * acceleration, ForceMode.Acceleration);
        else if (throttle < 0f && forwardSpeed > -8f)
            body.AddForce(transform.forward * throttle * reverseAcceleration, ForceMode.Acceleration);

        if (braking)
            body.velocity = Vector3.Lerp(body.velocity, Vector3.zero, brakePower * Time.fixedDeltaTime);

        float speedFactor = Mathf.Clamp01(body.velocity.magnitude / 4f);
        float direction = forwardSpeed >= -0.5f ? 1f : -1f;
        float yaw = steer * steering * speedFactor * direction * Time.fixedDeltaTime;
        body.MoveRotation(body.rotation * Quaternion.Euler(0f, yaw, 0f));

        // Arcade lateral grip keeps the car controllable with touch input.
        localVelocity = transform.InverseTransformDirection(body.velocity);
        localVelocity.x = Mathf.Lerp(localVelocity.x, 0f, lateralGrip * Time.fixedDeltaTime);
        body.velocity = transform.TransformDirection(localVelocity);
    }

    void Update()
    {
        if (carVisual == null) return;
        float targetLean = -steer * visualLean;
        Quaternion target = Quaternion.Euler(0f, 0f, targetLean);
        carVisual.localRotation = Quaternion.Lerp(carVisual.localRotation, target, 8f * Time.deltaTime);
    }
}

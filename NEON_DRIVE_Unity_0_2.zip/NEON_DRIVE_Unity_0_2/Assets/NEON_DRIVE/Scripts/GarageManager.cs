using UnityEngine;
using TMPro;

public class GarageManager : MonoBehaviour
{
    [System.Serializable]
    public class CarOption
    {
        public string displayName = "NEON GT";
        public GameObject carPrefab;
        public int unlockCost;
    }

    public CarOption[] cars;
    public Transform displayPoint;
    public TMP_Text carNameLabel;
    public TMP_Text creditsLabel;
    public int startingCredits = 2500;

    GameObject displayedCar;
    int selected;
    int credits;

    void Start()
    {
        credits = PlayerPrefs.GetInt("NEON_CREDITS", startingCredits);
        selected = Mathf.Clamp(PlayerPrefs.GetInt("NEON_CAR", 0), 0, Mathf.Max(0, cars.Length - 1));
        ShowSelected();
        RefreshUI();
    }

    public void NextCar()
    {
        if (cars == null || cars.Length == 0) return;
        selected = (selected + 1) % cars.Length;
        ShowSelected();
        RefreshUI();
    }

    public void PreviousCar()
    {
        if (cars == null || cars.Length == 0) return;
        selected = (selected - 1 + cars.Length) % cars.Length;
        ShowSelected();
        RefreshUI();
    }

    public void BuyOrSelect()
    {
        if (cars == null || cars.Length == 0) return;
        int cost = cars[selected].unlockCost;
        string key = "NEON_UNLOCK_" + selected;
        bool unlocked = selected == 0 || PlayerPrefs.GetInt(key, 0) == 1;
        if (!unlocked)
        {
            if (credits < cost) { RefreshUI(); return; }
            credits -= cost;
            PlayerPrefs.SetInt(key, 1);
            PlayerPrefs.SetInt("NEON_CREDITS", credits);
        }
        PlayerPrefs.SetInt("NEON_CAR", selected);
        RefreshUI();
    }

    void ShowSelected()
    {
        if (displayedCar != null) Destroy(displayedCar);
        if (cars == null || cars.Length == 0 || cars[selected].carPrefab == null || displayPoint == null) return;
        displayedCar = Instantiate(cars[selected].carPrefab, displayPoint.position, displayPoint.rotation, displayPoint);
        Rigidbody rb = displayedCar.GetComponent<Rigidbody>();
        if (rb != null) Destroy(rb);
        foreach (Collider c in displayedCar.GetComponentsInChildren<Collider>()) Destroy(c);
    }

    void RefreshUI()
    {
        if (cars == null || cars.Length == 0) return;
        bool unlocked = selected == 0 || PlayerPrefs.GetInt("NEON_UNLOCK_" + selected, 0) == 1;
        if (carNameLabel != null)
            carNameLabel.text = cars[selected].displayName + (unlocked ? "  •  OWNED" : "  •  " + cars[selected].unlockCost + " CR");
        if (creditsLabel != null) creditsLabel.text = credits + " CR";
    }
}

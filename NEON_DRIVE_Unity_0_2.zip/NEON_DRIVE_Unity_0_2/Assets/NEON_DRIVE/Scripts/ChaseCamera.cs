using UnityEngine;

public class ChaseCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0f, 4.2f, -8.5f);
    public float followSmooth = 7f;
    public float lookHeight = 1.2f;
    public float speedFovBoost = 8f;

    Camera cam;
    void Awake() { cam = GetComponent<Camera>(); }

    void LateUpdate()
    {
        if (target == null) return;
        Vector3 wanted = target.TransformPoint(offset);
        transform.position = Vector3.Lerp(transform.position, wanted, followSmooth * Time.deltaTime);

        Vector3 lookPoint = target.position + Vector3.up * lookHeight + target.forward * 4f;
        Quaternion wantedRotation = Quaternion.LookRotation(lookPoint - transform.position, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, wantedRotation, followSmooth * Time.deltaTime);

        if (cam != null)
        {
            Rigidbody rb = target.GetComponent<Rigidbody>();
            float speed = rb != null ? rb.velocity.magnitude : 0f;
            cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, 60f + speed * speedFovBoost / 40f, 3f * Time.deltaTime);
        }
    }
}

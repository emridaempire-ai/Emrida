# NEON DRIVE — Unity Starter 0.2

Расширенный стартовый набор скриптов для 3D гоночного прототипа под Android.
Это **проектные исходники и инструкции**, не готовый APK и не готовая сцена с арт-ассетами.

## Требования
- Unity 2022.3 LTS или Unity 6.
- Рекомендуется URP.
- Для Android установите Android Build Support, Android SDK & NDK Tools и OpenJDK через Unity Hub.
- В Player Settings задайте Active Input Handling = Both, если хотите пользоваться клавиатурными тестовыми осями старого Input Manager.

## Скрипты
- `ArcadeCarController.cs` — аркадное управление.
- `ChaseCamera.cs` — камера от третьего лица.
- `NeonDriveInput.cs` — сенсорные кнопки и клавиатурная проверка в редакторе.
- `NeonCityGenerator.cs` — процедурная сетка улиц, башни и неоновые линии.
- `NitroDriftSystem.cs` — нитро, заряд от дрифта и частицы.
- `TrafficCarAI.cs`, `TrafficSpawner.cs` — простой трафик по заданным точкам.
- `GarageManager.cs` — просмотр, покупка и выбор машин через PlayerPrefs.
- `NeonAudioSettings.cs` — громкость и качество графики.
- `NeonMenuController.cs` — меню, гараж, настройки и переход на гонку.
- `RaceManager.cs`, `RaceCheckpoint.cs` — скорость и финиш/чекпоинт.
- `NeonPulse.cs` — пульсация эмиссии.

## Быстрый порядок сборки
1. Создайте проект Unity 3D (URP), добавьте папку `Assets/NEON_DRIVE/Scripts` из архива.
2. Создайте сцену `NeonRace`. Добавьте пустой объект `CityGenerator`, назначьте `NeonCityGenerator`.
3. Создайте временную машину из Cube: назовите `PlayerCar`, Tag = Player, добавьте BoxCollider, Rigidbody, `ArcadeCarController` и `NitroDriftSystem`.
4. Создайте дочерний объект `CarVisual` (меш машины) и назначьте его в `carVisual`. Поставьте машину над дорогой на свободном прямом участке.
5. Добавьте камеру с `ChaseCamera`, назначьте `PlayerCar` в target.
6. Создайте `InputManager`, добавьте `NeonDriveInput`, назначьте PlayerCar в car.
7. На Canvas создайте кнопки Left, Right, Gas, Reverse, Brake, Nitro, Drift. Для удерживаемых кнопок используйте EventTrigger:
   - Pointer Down → метод Down
   - Pointer Up → метод Up
   Назначения: `LeftDown/LeftUp`, `RightDown/RightUp`, `GasDown/GasUp`, `ReverseDown/ReverseUp`, `BrakeDown/BrakeUp`, `NitroDown/NitroUp`, `DriftDown/DriftUp`.
8. Создайте пустой объект `RaceSystems`, добавьте `RaceManager`. Назначьте Player и финишный Transform. У финишной линии должен быть Collider с Is Trigger.
9. Для трафика создайте prefab машины с Collider (необязательно Rigidbody), добавьте `TrafficCarAI`. Расставьте пустые waypoint-объекты по замкнутому маршруту и назначьте их массиву `TrafficSpawner`.
10. Для гаража создайте сцену `MainMenu`, добавьте Canvas с панелями меню/гаража/настроек и подключите `NeonMenuController`. В `GarageManager` добавьте массив `CarOption`: первый автомобиль бесплатный, остальные с ценой и prefab.
11. Добавьте обе сцены в Build Profiles / Build Settings. В `NeonMenuController.raceSceneName` укажите `NeonRace`.

## Важные замечания
- Процедурный генератор создаёт простые геометрические башни и дороги — это блок-аут города. Для законченного визуала нужны модели, текстуры, вывески, дорожные разметки, VFX и аудио.
- Городская сетка — визуальная основа, не полноценная дорожная сеть с перекрёстками и правилами движения. Точки маршрута трафика расставляются вручную.
- Для URP Bloom включается через Global Volume: добавьте Bloom, Color Adjustments и Vignette; включите HDR на камере и URP Asset.
- На телефонах начните с низкого/среднего качества, ограничьте realtime lights и тени. Целевой FPS задайте через `Application.targetFrameRate = 60` на мобильном устройстве.
- Перед релизом проверьте управление на реальном устройстве, физику столкновений, разрешение UI, производительность и лицензионность всех импортированных ассетов.

using UnityEngine;
using UnityEngine.SceneManagement;

public class NeonMenuController : MonoBehaviour
{
    public string raceSceneName = "NeonRace";
    public GameObject mainMenu;
    public GameObject garagePanel;
    public GameObject settingsPanel;

    public void StartRace()
    {
        SceneManager.LoadScene(raceSceneName);
    }

    public void OpenGarage()
    {
        if (mainMenu != null) mainMenu.SetActive(false);
        if (garagePanel != null) garagePanel.SetActive(true);
    }

    public void OpenSettings()
    {
        if (mainMenu != null) mainMenu.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(true);
    }

    public void BackToMenu()
    {
        if (garagePanel != null) garagePanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(false);
        if (mainMenu != null) mainMenu.SetActive(true);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}

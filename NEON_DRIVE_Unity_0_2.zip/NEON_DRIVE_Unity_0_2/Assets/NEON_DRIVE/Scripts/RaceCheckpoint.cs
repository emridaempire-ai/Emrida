using UnityEngine;
using TMPro;

public class RaceCheckpoint : MonoBehaviour
{
    public TMP_Text message;
    public GameObject finishPanel;
    public string checkpointMessage = "CHECKPOINT!";
    bool passed;

    void OnTriggerEnter(Collider other)
    {
        if (passed || !other.CompareTag("Player")) return;
        passed = true;
        if (message != null) message.text = checkpointMessage;
        if (finishPanel != null) finishPanel.SetActive(true);
    }
}

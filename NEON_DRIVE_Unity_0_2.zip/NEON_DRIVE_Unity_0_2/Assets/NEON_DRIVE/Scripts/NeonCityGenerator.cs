using UnityEngine;

// Runtime block-city generator. Add to an empty GameObject in a new scene.
public class NeonCityGenerator : MonoBehaviour
{
    [Header("City layout")]
    [Min(2)] public int blocksX = 7;
    [Min(2)] public int blocksZ = 9;
    public float blockSize = 34f;
    public float roadWidth = 12f;
    public float roadThickness = 0.35f;
    public int randomSeed = 2026;

    [Header("Buildings")]
    public Vector2 buildingHeight = new Vector2(12f, 65f);
    public Vector2 buildingWidth = new Vector2(7f, 13f);
    public Material buildingMaterial;
    public Material roadMaterial;
    public Material neonCyanMaterial;
    public Material neonPinkMaterial;
    public bool generateOnStart = true;

    Transform cityRoot;

    void Start()
    {
        if (generateOnStart) Generate();
    }

    [ContextMenu("Generate City")]
    public void Generate()
    {
        if (cityRoot != null) Destroy(cityRoot.gameObject);
        cityRoot = new GameObject("Generated Neon City").transform;
        cityRoot.SetParent(transform, false);

        Random.InitState(randomSeed);
        Material roadMat = roadMaterial != null ? roadMaterial : MakeMaterial("Road Asphalt", new Color(0.025f, 0.035f, 0.065f), false);
        Material buildingMat = buildingMaterial != null ? buildingMaterial : MakeMaterial("Building Dark", new Color(0.045f, 0.055f, 0.09f), false);
        Material cyan = neonCyanMaterial != null ? neonCyanMaterial : MakeMaterial("Neon Cyan", new Color(0.02f, 0.75f, 1f), true);
        Material pink = neonPinkMaterial != null ? neonPinkMaterial : MakeMaterial("Neon Pink", new Color(1f, 0.025f, 0.42f), true);

        float totalX = blocksX * blockSize;
        float totalZ = blocksZ * blockSize;
        CreateCube("City Ground", new Vector3(totalX * .5f, -0.5f, totalZ * .5f),
            new Vector3(totalX + roadWidth * 2f, 1f, totalZ + roadWidth * 2f),
            MakeMaterial("Night Ground", new Color(0.008f, 0.012f, 0.028f), false));

        // Continuous road strips form a simple Manhattan-style grid.
        for (int x = 0; x <= blocksX; x++)
        {
            float px = x * blockSize;
            CreateCube("Road North South", new Vector3(px, -0.12f, totalZ * .5f),
                new Vector3(roadWidth, roadThickness, totalZ + roadWidth), roadMat);
            CreateRoadLine(new Vector3(px - roadWidth * .28f, 0.06f, totalZ * .5f), totalZ + roadWidth, true, cyan);
            CreateRoadLine(new Vector3(px + roadWidth * .28f, 0.06f, totalZ * .5f), totalZ + roadWidth, true, pink);
        }
        for (int z = 0; z <= blocksZ; z++)
        {
            float pz = z * blockSize;
            CreateCube("Road East West", new Vector3(totalX * .5f, -0.11f, pz),
                new Vector3(totalX + roadWidth, roadThickness, roadWidth), roadMat);
        }

        for (int x = 0; x < blocksX; x++)
        for (int z = 0; z < blocksZ; z++)
        {
            Vector3 center = new Vector3(x * blockSize + blockSize * .5f, 0f,
                                         z * blockSize + blockSize * .5f);
            CreateBlockBuildings(center, buildingMat, cyan, pink);
        }

        // Sparse street lamps and glowing overhead signs.
        for (int x = 0; x <= blocksX; x++)
        for (int z = 0; z <= blocksZ; z++)
        {
            if ((x + z) % 2 == 0)
                CreateStreetLamp(new Vector3(x * blockSize + roadWidth * .65f, 0f,
                                              z * blockSize + roadWidth * .65f), cyan);
        }
    }

    void CreateBlockBuildings(Vector3 center, Material baseMat, Material cyan, Material pink)
    {
        int count = Random.Range(2, 5);
        for (int i = 0; i < count; i++)
        {
            float w = Random.Range(buildingWidth.x, buildingWidth.y);
            float d = Random.Range(buildingWidth.x, buildingWidth.y);
            float h = Random.Range(buildingHeight.x, buildingHeight.y);
            float offsetX = Random.Range(-blockSize * .28f, blockSize * .28f);
            float offsetZ = Random.Range(-blockSize * .28f, blockSize * .28f);
            Vector3 pos = center + new Vector3(offsetX, h * .5f, offsetZ);
            GameObject building = CreateCube("Tower", pos, new Vector3(w, h, d), baseMat);
            building.isStatic = true;

            // Vertical neon corner strips and rooftop sign.
            CreateCube("Cyan facade strip", pos + new Vector3(w * .5f + .025f, 0f, -d * .25f),
                new Vector3(.09f, h * .92f, .09f), cyan);
            if (Random.value > .45f)
                CreateCube("Pink facade strip", pos + new Vector3(-w * .5f - .025f, 0f, d * .25f),
                    new Vector3(.09f, h * .82f, .09f), pink);
            if (Random.value > .55f)
                CreateCube("Rooftop sign", pos + new Vector3(0f, h * .5f + .35f, 0f),
                    new Vector3(w * .72f, .22f, .35f), Random.value > .5f ? cyan : pink);
        }
    }

    void CreateStreetLamp(Vector3 p, Material glow)
    {
        CreateCube("Lamp Pole", p + Vector3.up * 3f, new Vector3(.12f, 6f, .12f),
            MakeMaterial("Lamp Metal", new Color(.06f, .08f, .12f), false));
        CreateCube("Lamp Head", p + Vector3.up * 6.05f, new Vector3(1.5f, .12f, .25f), glow);
    }

    void CreateRoadLine(Vector3 p, float length, bool alongZ, Material mat)
    {
        Vector3 scale = alongZ ? new Vector3(.08f, .025f, length) : new Vector3(length, .025f, .08f);
        CreateCube("Neon Road Edge", p, scale, mat);
    }

    GameObject CreateCube(string name, Vector3 position, Vector3 scale, Material mat)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(cityRoot, false);
        go.transform.position = position;
        go.transform.localScale = scale;
        if (mat != null) go.GetComponent<Renderer>().sharedMaterial = mat;
        return go;
    }

    Material MakeMaterial(string name, Color color, bool emission)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        Material mat = new Material(shader);
        mat.name = name;
        mat.color = color;
        if (emission)
        {
            mat.EnableKeyword("_EMISSION");
            mat.SetColor("_EmissionColor", color * 2.4f);
        }
        return mat;
    }
}

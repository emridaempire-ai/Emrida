using UnityEngine;

public class TrafficCarAI : MonoBehaviour
{
    public Transform[] waypoints;
    public float speed = 12f;
    public float turnSpeed = 4f;
    public float waypointRadius = 4f;
    int current;

    void Update()
    {
        if (waypoints == null || waypoints.Length == 0) return;
        Transform target = waypoints[current];
        Vector3 direction = target.position - transform.position;
        direction.y = 0f;

        if (direction.magnitude < waypointRadius)
        {
            current = (current + 1) % waypoints.Length;
            return;
        }

        Quaternion look = Quaternion.LookRotation(direction.normalized, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, look, turnSpeed * Time.deltaTime);
        transform.position += transform.forward * speed * Time.deltaTime;
    }
}

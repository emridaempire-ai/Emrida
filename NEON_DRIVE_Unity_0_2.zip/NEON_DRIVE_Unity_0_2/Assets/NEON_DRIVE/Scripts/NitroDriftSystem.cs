using UnityEngine;
using UnityEngine.UI;
using TMPro;

[RequireComponent(typeof(Rigidbody))]
public class NitroDriftSystem : MonoBehaviour
{
    public float nitroForce = 24f;
    public float nitroSeconds = 2.4f;
    public float rechargePerSecond = 0.18f;
    public float driftChargePerSecond = 0.16f;
    public Slider nitroBar;
    public TMP_Text nitroLabel;
    public ParticleSystem nitroParticles;

    Rigidbody body;
    float nitro = 1f;
    bool nitroHeld;
    bool drifting;
    bool nitroActive;

    void Awake() { body = GetComponent<Rigidbody>(); }
    public void NitroDown() { nitroHeld = true; }
    public void NitroUp() { nitroHeld = false; }
    public void DriftDown() { drifting = true; }
    public void DriftUp() { drifting = false; }

    void Update()
    {
        if (drifting && body.velocity.magnitude > 7f)
            nitro = Mathf.Clamp01(nitro + driftChargePerSecond * Time.deltaTime);
        else if (!nitroActive)
            nitro = Mathf.Clamp01(nitro + rechargePerSecond * Time.deltaTime);

        nitroActive = nitroHeld && nitro > 0.01f;
        if (nitroActive) nitro = Mathf.Max(0f, nitro - Time.deltaTime / nitroSeconds);
        if (nitroBar != null) nitroBar.value = nitro;
        if (nitroLabel != null) nitroLabel.text = nitroActive ? "NITRO" : "BOOST";
        if (nitroParticles != null)
        {
            if (nitroActive && !nitroParticles.isPlaying) nitroParticles.Play();
            if (!nitroActive && nitroParticles.isPlaying) nitroParticles.Stop();
        }
    }

    void FixedUpdate()
    {
        if (nitroActive) body.AddForce(transform.forward * nitroForce, ForceMode.Acceleration);
        if (drifting && body.velocity.magnitude > 8f)
        {
            Vector3 side = transform.right * Vector3.Dot(body.velocity, transform.right);
            body.AddForce(-side * 1.4f, ForceMode.Acceleration);
        }
    }
}

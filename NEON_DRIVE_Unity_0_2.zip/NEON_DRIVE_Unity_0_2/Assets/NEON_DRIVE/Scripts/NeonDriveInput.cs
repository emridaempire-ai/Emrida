using UnityEngine;
using UnityEngine.EventSystems;

// Connect the UI buttons to these public methods using Button OnClick / EventTrigger.
// Keyboard controls are included for quick testing in the Unity Editor.
public class NeonDriveInput : MonoBehaviour
{
    public ArcadeCarController car;
    bool left, right, gas, reverse, brake;

    public void LeftDown() => left = true;
    public void LeftUp() => left = false;
    public void RightDown() => right = true;
    public void RightUp() => right = false;
    public void GasDown() => gas = true;
    public void GasUp() => gas = false;
    public void ReverseDown() => reverse = true;
    public void ReverseUp() => reverse = false;
    public void BrakeDown() => brake = true;
    public void BrakeUp() => brake = false;

    void Update()
    {
        float turn = (right ? 1f : 0f) - (left ? 1f : 0f);
        float throttle = (gas ? 1f : 0f) - (reverse ? 1f : 0f);

#if UNITY_EDITOR || UNITY_STANDALONE
        turn = Mathf.Abs(Input.GetAxisRaw("Horizontal")) > 0.01f ? Input.GetAxisRaw("Horizontal") : turn;
        throttle = Mathf.Abs(Input.GetAxisRaw("Vertical")) > 0.01f ? Input.GetAxisRaw("Vertical") : throttle;
        brake |= Input.GetKey(KeyCode.Space);
#endif
        if (car != null) car.SetInput(throttle, turn, brake);
    }
}
